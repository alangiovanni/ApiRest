package com.servicenet.apirest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.servicenet.apirest.modelos.Usuario;

//jpa repository possui varios métodos para persistência no banco de dados
public interface UsuarioRepository extends JpaRepository<Usuario, String>{
	Usuario findByNome(String nome);
	Usuario findByMatricula(int matricula);

}
