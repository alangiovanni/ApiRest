package com.servicenet.apirest.resources;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.servicenet.apirest.repository.UsuarioRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import com.servicenet.apirest.modelos.Usuario;;


@RestController
@RequestMapping(value="/api")
@Api(value="API REST PROJETO 1")
@CrossOrigin(origins="*") //libera todos os dominios para acessar esta API

public class UsuarioResource {
	@Autowired
	UsuarioRepository usuarioRepository;
	
	@GetMapping("/listar")
	@ApiOperation(value="Retorna uma lista de usuarios")
	public List<Usuario> listaUsuarios(){
		return usuarioRepository.findAll();
	}
	
	@GetMapping("/listar/{nome}")
	@ApiOperation(value="Retorna um único usuario pelo nome")
	public Usuario listaUsuario(@PathVariable(value="nome") String nome){
		return usuarioRepository.findByNome(nome);
	}
	
	@PostMapping("/cadastrar")
	@ApiOperation(value="Cadastra um usuário com a senha criptografada")
	public Usuario salvaUsuario(@RequestBody Usuario usuario) {
		//Encriptando a senha recebida pela requisição
		try {
			usuario.criptografar();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return usuarioRepository.save(usuario);
	}
	
	@DeleteMapping("/deletar/{matricula}")
	@ApiOperation(value="Deleta um usuário específico através da matricula")
	public void deletaUsuario(@PathVariable(value="matricula") int matricula){
		usuarioRepository.delete(usuarioRepository.findByMatricula(matricula));
	}
	
	@PutMapping("/atualizar")
	@ApiOperation(value="Atualiza um usuário específico")
	public Usuario atualizaUsuario(@RequestBody Usuario usuario){
		int matricula = usuario.getMatricula();
		Usuario usuarioCadastrado = usuarioRepository.findByMatricula(matricula);
		
		//Caso a senha seja atualizada é aplicado a criptografia sobre a senha
		if(!(usuarioCadastrado.getSenha().equals(usuario.getSenha()))) {
			//Encriptando a senha recebida pela requisição
			try {
				usuario.criptografar();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return usuarioRepository.save(usuario);
	}
}
